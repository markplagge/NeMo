var searchData=
[
  ['cust_5flinear',['CUST_LINEAR',['../assist_8h.html#a3ef69bf66737bc38927fa7ac64dd7a21a572edf25b7d236df9162e2ae3851f530',1,'assist.h']]]
];
