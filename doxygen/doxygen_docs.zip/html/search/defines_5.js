var searchData=
[
  ['iabs',['IABS',['../assist_8h.html#aaf4b596256d346dd40bc6f14c3eb9371',1,'assist.h']]],
  ['iside',['ISIDE',['../mapping_8h.html#aeb3898b2cf3e71a112756d8c2b4cb89b',1,'mapping.h']]]
];
