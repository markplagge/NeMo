var searchData=
[
  ['synapse_2ec',['synapse.c',['../synapse_8c.html',1,'']]],
  ['synapse_2eh',['synapse.h',['../synapse_8h.html',1,'']]]
];
