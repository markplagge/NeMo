var searchData=
[
  ['field_5fbegun',['FIELD_BEGUN',['../libcsv_8c.html#aeb6e4175a8c79aa99f8da332b6fe62af',1,'libcsv.c']]],
  ['field_5fmight_5fhave_5fended',['FIELD_MIGHT_HAVE_ENDED',['../libcsv_8c.html#a5c0e812d40c0a8c74fab6ce4470aa251',1,'libcsv.c']]],
  ['field_5fnot_5fbegun',['FIELD_NOT_BEGUN',['../libcsv_8c.html#aba08ab8c86cf7bbfa7b273bba5c8f790',1,'libcsv.c']]]
];
