var searchData=
[
  ['row_5fnot_5fbegun',['ROW_NOT_BEGUN',['../libcsv_8c.html#a0dde908c580ee4b9b134794d9b09f202',1,'libcsv.c']]],
  ['rzer',['RZER',['../assist_8h.html#ad383c153e77508e2556003da0e4ac3eb',1,'assist.h']]]
];
