var searchData=
[
  ['jside',['JSIDE',['../mapping_8h.html#a634c7b1287d8bcb0e6d7c119f1619666',1,'mapping.h']]],
  ['jsizeoffset',['jSizeOffset',['../mapping_8c.html#adb68daa0551a882de907f2d7877b63cf',1,'jSizeOffset():&#160;mapping.c'],['../mapping_8h.html#adb68daa0551a882de907f2d7877b63cf',1,'jSizeOffset():&#160;mapping.c']]],
  ['jval',['jVal',['../mapping_8c.html#ac87e302e9bacffad6acd9477db09b164',1,'mapping.c']]]
];
