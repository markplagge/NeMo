var searchData=
[
  ['quote_5fchar',['quote_char',['../structcsv__parser.html#a065023bbecdc489441e184f5b06463e3',1,'csv_parser']]],
  ['quoted',['quoted',['../structcsv__parser.html#a17cf94344b659e2d1785109db2028acd',1,'csv_parser']]]
];
