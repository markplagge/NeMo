var searchData=
[
  ['bincomp',['BINCOMP',['../assist_8h.html#abbf94867faa4abd8c53c87576efd05f3',1,'assist.h']]]
];
