var searchData=
[
  ['thresh_5ftype',['thresh_type',['../assist_8h.html#a69e4d1ceb8b0e29543ed365a3169173d',1,'assist.h']]],
  ['timerandomsel',['timeRandomSel',['../assist_8h.html#a65fddfa4d0b49e55af95461e72532331',1,'assist.h']]]
];
