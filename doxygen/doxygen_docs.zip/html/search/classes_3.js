var searchData=
[
  ['globalid',['GlobalID',['../union_global_i_d.html',1,'']]]
];
