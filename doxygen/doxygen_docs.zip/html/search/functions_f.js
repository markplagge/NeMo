var searchData=
[
  ['uniformgen',['uniformGen',['../input__simulator_8c.html#a7ffa6df128d9c249ace6677ae62d1723',1,'uniformGen(void *spikeGen, tw_lp *lp):&#160;input_simulator.c'],['../input__simulator_8h.html#ad6244e86a3542f8d3c64766e7e7c6746',1,'uniformGen(void *gen_state, tw_lp *lp):&#160;input_simulator.c']]]
];
