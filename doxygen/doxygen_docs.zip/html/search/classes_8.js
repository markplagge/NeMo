var searchData=
[
  ['selectedspikes',['SelectedSpikes',['../struct_selected_spikes.html',1,'']]],
  ['supernstats',['supernStats',['../structsupern_stats.html',1,'']]],
  ['synapsestate',['SynapseState',['../struct_synapse_state.html',1,'']]]
];
