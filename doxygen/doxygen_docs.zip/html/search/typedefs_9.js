var searchData=
[
  ['volt_5ftype',['volt_type',['../assist_8h.html#aa48c5a87655290f08b5327c5b7348394',1,'assist.h']]]
];
