var searchData=
[
  ['rand_5ftype',['rand_type',['../assist_8h.html#af140a54c70d57b056b18b34c8bc8a384',1,'assist.h']]],
  ['randomspikes',['randomSpikes',['../input__simulator_8h.html#a077bb7510f16566ab2e778d66c48aaf7',1,'input_simulator.h']]],
  ['regid_5ftype',['regID_type',['../assist_8h.html#aceb195884c06d69a70ed9218f5054d5d',1,'assist.h']]],
  ['resetfundel',['resetFunDel',['../neuron_8h.html#ae7e5990745cd949246894bfb633ca4a2',1,'neuron.h']]]
];
