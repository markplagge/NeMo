var searchData=
[
  ['kappa',['kappa',['../struct_neuron_model.html#a2b2cbf88a994c83479890954e6c5decf',1,'NeuronModel']]]
];
