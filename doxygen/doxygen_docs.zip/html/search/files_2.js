var searchData=
[
  ['generate_5ftonic_5fspiking_2ec',['generate_tonic_spiking.c',['../generate__tonic__spiking_8c.html',1,'']]],
  ['generate_5ftonic_5fspiking_2eh',['generate_tonic_spiking.h',['../generate__tonic__spiking_8h.html',1,'']]]
];
