var searchData=
[
  ['weight_5ftype',['weight_type',['../assist_8h.html#aee993e476cc7f92351c40099ef6519ab',1,'assist.h']]]
];
