var searchData=
[
  ['evttype',['evtType',['../assist_8h.html#a7c1688de451e0dea1e11617bce3ec450',1,'assist.h']]]
];
