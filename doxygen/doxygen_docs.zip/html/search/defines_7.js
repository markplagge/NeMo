var searchData=
[
  ['lc',['lc',['../mapping_8h.html#a16e4120afe5c318e813843317ab5c6a2',1,'mapping.h']]],
  ['local',['LOCAL',['../mapping_8h.html#ac16668f3a709be2c2bce05d767ed3495',1,'mapping.h']]]
];
