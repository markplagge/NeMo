var searchData=
[
  ['jsizeoffset',['jSizeOffset',['../mapping_8c.html#adb68daa0551a882de907f2d7877b63cf',1,'jSizeOffset():&#160;mapping.c'],['../mapping_8h.html#adb68daa0551a882de907f2d7877b63cf',1,'jSizeOffset():&#160;mapping.c']]],
  ['jval',['jVal',['../mapping_8c.html#ac87e302e9bacffad6acd9477db09b164',1,'mapping.c']]]
];
