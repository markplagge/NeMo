var searchData=
[
  ['randomspikes',['RandomSpikes',['../struct_random_spikes.html',1,'']]]
];
