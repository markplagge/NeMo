var searchData=
[
  ['unf',['UNF',['../input__simulator_8h.html#af21d2b6d21114a3f698a082ec306f9f3a4b3574e75cec43aa4dd3a0fd7940c632',1,'input_simulator.h']]],
  ['uniformgen',['uniformGen',['../input__simulator_8c.html#a7ffa6df128d9c249ace6677ae62d1723',1,'uniformGen(void *spikeGen, tw_lp *lp):&#160;input_simulator.c'],['../input__simulator_8h.html#ad6244e86a3542f8d3c64766e7e7c6746',1,'uniformGen(void *gen_state, tw_lp *lp):&#160;input_simulator.c']]]
];
