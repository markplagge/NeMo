var searchData=
[
  ['newlog',['newlog',['../model__main_8h.html#a7f846813a5e78f4e427a1147da35efe3',1,'model_main.h']]],
  ['nlog',['nlog',['../model__main_8h.html#a0b6a3a4e5d3d8e488744bf3b520d0aae',1,'model_main.h']]]
];
